#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 1 

Template file for detect_fault_main

@author: 
"""

def detect_fault_main(conc_signal,conc_range,conc_var,conc_cusum_limit, 
                  flow_signal,flow_range,flow_control_window):
    
    import classify_fault as classify
    
