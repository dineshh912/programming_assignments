#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 1 

Template file for calc_signal_log_prob_ratio()

@author: 
"""

def calc_signal_log_prob_ratio(conc_signal,conc_range,conc_var):
    
    import calc_log_prob_ratio as clpr
    
 