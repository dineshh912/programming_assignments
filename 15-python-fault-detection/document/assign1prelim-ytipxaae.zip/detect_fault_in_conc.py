#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 1 

Template file for detect_fault_in_conc

@author: 
"""

def detect_fault_in_conc(conc_cusum,conc_cusum_limit):
    
