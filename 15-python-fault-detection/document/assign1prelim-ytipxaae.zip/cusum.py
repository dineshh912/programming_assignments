#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 1 

Template file for cusum()

@author: 
"""

def cusum(conc_lpr):
    
   