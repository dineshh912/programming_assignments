#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 1 

Template file for calc_log_prob_ratio()

@author: 
"""

def calc_log_prob_ratio(measurement, conc_range, conc_var):
    
