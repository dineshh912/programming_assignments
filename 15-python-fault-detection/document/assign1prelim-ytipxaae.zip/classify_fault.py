#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ENGG1811 21T3 Assignment 1 

Template file for classify_fault()

@author: 
"""

def classify_fault(conc_signal,conc_range,conc_var,conc_cusum_limit, 
                   flow_signal,flow_range,flow_control_window):
    
    import calc_signal_log_prob_ratio as cslpr
    import cusum as cs
    import detect_fault_in_conc as detect

    
