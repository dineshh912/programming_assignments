from matplotlib import pyplot as plt

# recommended color for different digits
color_mapping = {0:'red',1:'green',2:'blue',3:'yellow',4:'magenta',5:'orangered',
                6:'cyan',7:'purple',8:'gold',9:'pink'}

def plot2d(data,label,split='train'):
    # 2d scatter plot of the hidden features
    pass

def plot3d(data,label,split='train'):
    # 3d scatter plot of the hidden features
    pass
