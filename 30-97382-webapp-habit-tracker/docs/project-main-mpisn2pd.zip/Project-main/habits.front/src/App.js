import logo from './logo.svg';
import './App.css';

import Layout from './styles/Layout';

function App() {
  return (
    <Layout />
  );
}

export default App;
