import React from 'react';

import { Container } from '@mui/material';

function Feed() {
  return (
    <Container>
      <p>Content</p>
    </Container>
  );
}

export default React.memo(Feed);